/*
 * Off-Grid Chat front end.
 *
 * Demo mode: stores sample posts in this browser's localStorage.
 * ESP8266 mode: set API_BASE to "" and implement the endpoints documented
 * in README.md. The ESP8266, not this browser, must persist shared messages.
 */
(() => {
  "use strict";

  const API_BASE = ""; // Same-origin ESP8266 API. Keep blank for demo mode.
  const DEMO_KEY = "offgrid-chat-demo-v1";
  const USER_KEY = "offgrid-chat-username-v1";
  const POLL_MS = 5000;
  const MAX_POST = 280;
  const MAX_REPLY = 160;

  const $ = (id) => document.getElementById(id);
  const feed = $("feed");
  const usernameInput = $("username");
  let username = localStorage.getItem(USER_KEY) || "";
  let messages = [];
  let sending = false;
  // Preserve reply UI and unfinished drafts when the feed is refreshed.
  const openReplyForms = new Set();
  const replyDrafts = new Map();

  const demoSeed = [
    {
      id: "demo-1", username: "nilltronic", text: "Messages stay forever, even when you leave. Be nice and have fun!",
      timestamp: Date.now() - 1000 * 60 * 18, replies: []
    },
    {
      id: "demo-2", username: "nilltronic", text: "Hi, leave a message for others that join the Off-Grid-Chat",
      timestamp: Date.now() - 1000 * 60 * 12,
      replies: [
        { id: "demo-r1", username: "nilltronic", text: "Any one logged in at the same time can chat in realtime.", timestamp: Date.now() - 1000 * 60 * 5 }
      ]
    }
    
  ];

  function readDemo() {
    try {
      const raw = localStorage.getItem(DEMO_KEY);
      if (!raw) {
        localStorage.setItem(DEMO_KEY, JSON.stringify(demoSeed));
        return demoSeed;
      }
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch (_) { return []; }
  }

  function saveDemo() {
    try { localStorage.setItem(DEMO_KEY, JSON.stringify(messages)); }
    catch (_) { setStatus("Browser storage is full; this post was not saved."); }
  }

  async function request(path, options) {
    const response = await fetch(API_BASE + path, {
      cache: "no-store",
      headers: { ...(options && options.headers || {}) },
      ...options
    });
    if (!response.ok) throw new Error("Server returned " + response.status);
    return response.status === 204 ? null : response.json();
  }

  function setStatus(text) { $("feed-status").textContent = text; }

  async function loadMessages() {
    try {
      if (API_BASE !== null && window.location.protocol !== "file:") {
        // API_BASE is blank for a same-origin ESP8266 deployment.
        const data = await request("/api/messages");
        messages = Array.isArray(data.messages) ? data.messages : [];
        $("online-count").textContent = Number.isFinite(data.online) ? data.online : "—";
        setStatus("Connected to the local board · updates every 5 seconds");
      } else {
        messages = readDemo();
        $("online-count").textContent = username ? "1" : "1";
        setStatus("Browser preview mode · messages are only stored in this browser");
      }
      render();
    } catch (error) {
      // A failed API request must not silently switch to local-only data:
      // that could make visitors think a post was shared when it was not.
      setStatus("Could not reach the board. Check the local server connection.");
      if (!messages.length) render();
    }
  }

  function escapeText(text) {
    return String(text).replace(/[&<>"']/g, ch => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[ch]);
  }

  function formatText(text) {
    // Escape first; only then add controlled mention markup.
    return escapeText(text).replace(/(^|\s)@([a-zA-Z0-9_-]{1,20})\b/g,
      '$1<span class="mention">@$2</span>');
  }

  function formatTime(timestamp) {
    if (!timestamp) return "Time unavailable";
    const date = new Date(timestamp);
    if (Number.isNaN(date.getTime())) return "";
    return date.toLocaleString([], { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
  }

  function renderReply(reply) {
    const node = document.createElement("div");
    node.className = "reply";
    const head = document.createElement("div");
    head.className = "reply-head";
    const author = document.createElement("strong");
    author.textContent = reply.username;
    const time = document.createElement("time");
    time.textContent = formatTime(reply.timestamp);
    head.append(author, time);
    const body = document.createElement("p");
    body.innerHTML = formatText(reply.text);
    node.append(head, body);
    return node;
  }

  function render() {
    // Save the current reply form state before replacing the message cards.
    feed.querySelectorAll(".message").forEach(card => {
      const id = card.dataset.id;
      const form = card.querySelector(".reply-form");
      const field = form && form.querySelector("textarea");
      if (!id || !form) return;
      if (form.classList.contains("hidden")) openReplyForms.delete(id);
      else openReplyForms.add(id);
      if (field) replyDrafts.set(id, field.value);
    });
    feed.replaceChildren();
    if (!messages.length) {
      const empty = document.createElement("div");
      empty.className = "empty panel";
      empty.textContent = "It's quiet here. Start the conversation!";
      feed.append(empty);
      return;
    }

    const template = $("message-template");
    [...messages].sort((a, b) => b.timestamp - a.timestamp).forEach(message => {
      const node = template.content.firstElementChild.cloneNode(true);
      node.dataset.id = message.id;
      node.querySelector(".avatar").textContent = (message.username || "?").slice(0, 1).toUpperCase();
      node.querySelector(".author").textContent = message.username;
      node.querySelector(".timestamp").textContent = formatTime(message.timestamp);
      node.querySelector(".message-text").innerHTML = formatText(message.text);

      const replies = node.querySelector(".replies");
      (message.replies || []).forEach(reply => replies.append(renderReply(reply)));

      const toggle = node.querySelector(".reply-toggle");
      const form = node.querySelector(".reply-form");
      const replyField = form.querySelector("textarea");
      if (openReplyForms.has(message.id)) form.classList.remove("hidden");
      replyField.value = replyDrafts.get(message.id) || "";
      toggle.addEventListener("click", () => {
        if (!username) { usernameInput.focus(); setStatus("Choose a username before replying."); return; }
        form.classList.toggle("hidden");
        if (form.classList.contains("hidden")) openReplyForms.delete(message.id);
        else {
          openReplyForms.add(message.id);
          replyField.focus();
        }
      });
      replyField.addEventListener("input", () => replyDrafts.set(message.id, replyField.value));
      form.addEventListener("submit", event => {
        event.preventDefault();
        submitReply(message.id, replyField.value);
      });
      feed.append(node);
    });
  }

  async function submitPost() {
    const field = $("new-message");
    const text = field.value.trim();
    if (!username) { usernameInput.focus(); setStatus("Choose a username before posting."); return; }
    if (!text || text.length > MAX_POST || sending) return;
    sending = true;
    $("post-button").disabled = true;
    try {
      if (window.location.protocol !== "file:" && API_BASE !== null) {
        await request("/api/messages", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ username, text, timestamp: String(Math.floor(Date.now() / 1000)) }) });
        field.value = "";
        $("message-length").textContent = "0";
        await loadMessages();
      } else {
        messages.push({ id: "local-" + Date.now(), username, text, timestamp: Date.now(), replies: [] });
        saveDemo(); field.value = ""; $("message-length").textContent = "0"; render();
      }
    } catch (_) { setStatus("Post failed. Please try again when the board is reachable."); }
    sending = false;
    $("post-button").disabled = !field.value.trim();
  }

  async function submitReply(messageId, rawText) {
    const text = rawText.trim();
    if (!username || !text || text.length > MAX_REPLY) return false;
    try {
      if (window.location.protocol !== "file:" && API_BASE !== null) {
        await request("/api/replies", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ messageId, username, text, timestamp: String(Math.floor(Date.now() / 1000)) }) });
        replyDrafts.delete(messageId);
        await loadMessages();
      } else {
        const message = messages.find(item => item.id === messageId);
        if (!message) return false;
        message.replies = message.replies || [];
        message.replies.push({ id: "local-" + Date.now(), username, text, timestamp: Date.now() });
        replyDrafts.delete(messageId);
        saveDemo(); render();
      }
      return true;
    } catch (_) { setStatus("Reply failed. Please try again."); return false; }
  }

  $("username-form").addEventListener("submit", event => {
    event.preventDefault();
    const candidate = usernameInput.value.trim();
    if (!/^[a-zA-Z0-9_-]{2,20}$/.test(candidate)) {
      setStatus("Usernames must be 2–20 characters: letters, numbers, _ or -.");
      return;
    }
    username = candidate;
    localStorage.setItem(USER_KEY, username);
    updateIdentity();
  });

  function updateIdentity() {
    $("welcome-title").textContent = username ? "Welcome, " + username : "Welcome, visitor";
    $("identity-note").textContent = username ? "Your name is saved on this device." : "Choose a username to join the conversation.";
    usernameInput.value = username;
    $("post-button").disabled = !$("new-message").value.trim() || !username;
  }

  $("new-message").addEventListener("input", event => {
    $("message-length").textContent = event.target.value.length;
    $("post-button").disabled = !event.target.value.trim() || !username || event.target.value.length > MAX_POST;
  });
  $("post-button").addEventListener("click", submitPost);
  $("refresh-button").addEventListener("click", loadMessages);

  updateIdentity();
  loadMessages();
  // Poll only when the page is visible; avoids needless requests on idle phones.
  setInterval(() => { if (!document.hidden) loadMessages(); }, POLL_MS);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) loadMessages(); });
})();
